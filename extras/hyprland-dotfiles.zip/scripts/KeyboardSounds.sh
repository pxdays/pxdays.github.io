#!/bin/bash
# Random keyboard click sounds for Hyprland

SOUNDS_DIR="$HOME/.config/hypr/sounds"
SOUNDS=("$SOUNDS_DIR"/*.wav)
paplay "${SOUNDS[RANDOM % ${#SOUNDS[@]}]}" &
# --- 🦞 pxdays.github.io ---
