#!/usr/bin/env bash

dir="$HOME/Pictures/Screenshots"
file="Screenshot_$(date "+%Y%m%d_%H%M%S").png"

mkdir -p "$dir"
grim -g "$(slurp -d)" - | tee "$dir/$file" | wl-copy

# --- 🦞 pxdays.github.io ---
