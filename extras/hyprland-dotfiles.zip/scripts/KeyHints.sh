#!/usr/bin/env bash
# /* ---- 💫 https://github.com/pxdays 💫 ---- */  ##

# Check if rofi is running
pkill rofi 2>/dev/null

# Create a custom keybinds list
echo -e "Super = Windows Key\nSuper+D = App Launcher\nSuper+W = Wallpaper\nSuper+Return = Terminal\nSuper+Q = Close Window\nSuper+F = Fullscreen\nSuper+Space = Fuzzy Search\nSuper+H = This Menu\nSuper+Shift+E = Settings\nCtrl+Alt+L = Lock Screen\nSuper+V = Clipboard\n\nPress ESC to close" | rofi -dmenu \
  -theme-str 'window {background: #1a1a1a;} entry {foreground: #FF69B4;} text {foreground: #FF69B4;}' \
  -theme-str 'element-text {foreground: #FF69B4;} element-icon {foreground: #FF69B4;}' \
  -theme-str 'window {border: 2px; border-color: #FF69B4;}' \
  -mesg "Super+H = Key Hints" \
  -kb-cancel "Escape"
# --- 🦞 pxdays.github.io ---
