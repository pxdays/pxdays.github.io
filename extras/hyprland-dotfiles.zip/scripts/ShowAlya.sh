#!/bin/bash
# Launch Alya GIF floating in top right
mpv --no-audio --loop --geometry=280x160 --autofit=280x160 --osc=no ~/Downloads/alya.gif --force-window &
sleep 2
# Move to top right of screen using hyprland window rule
hyprctl dispatch movewindowpixel "exact -290 50,class:mpv" 2>/dev/null || true
# --- 🦞 pxdays.github.io ---
