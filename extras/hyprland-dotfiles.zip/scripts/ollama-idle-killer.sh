#!/bin/bash
# Ollama auto-kill script - kills ollama after 120s of inactivity

IDLE_TIME=120
CHECK_INTERVAL=10

while true; do
    # Check if ollama is running
    if pgrep -x "ollama" > /dev/null; then
        # Check for recent activity on port 11434 (ollama default port)
        if ! ss -tn | grep -q ":11434 "; then
            # No active connections, increment idle counter
            if [ -z "$idle_count" ]; then
                idle_count=1
            else
                idle_count=$((idle_count + 1))
            fi
            
            # If idle for 120 seconds
            if [ $((idle_count * CHECK_INTERVAL)) -ge $IDLE_TIME ]; then
                pkill -x ollama
                echo "Ollama killed after ${IDLE_TIME}s of inactivity"
                idle_count=0
            fi
        else
            # Active connection detected, reset counter
            idle_count=0
        fi
    else
        idle_count=0
    fi
    
    sleep $CHECK_INTERVAL
done
# --- 🦞 pxdays.github.io ---
