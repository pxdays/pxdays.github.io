#!/usr/bin/env bash
# ──────────────────────────────────────────────
#  Hyprland Dotfiles Installer
#  https://pxdays.github.io
#  Super sinister black & red theme 🖤❤️
# ──────────────────────────────────────────────
#  This script will:
#  1. Install Hyprland + required packages
#  2. Back up your existing config
#  3. Apply pxdays' dotfiles
#  4. Set everything up
# ──────────────────────────────────────────────

set -euo pipefail

# ── Colors ──
R="\e[1;31m"; G="\e[1;32m"; Y="\e[1;33m"; B="\e[1;34m"; M="\e[1;35m"; C="\e[1;36m"; W="\e[1;37m"; N="\e[0m"

echo -e "${R}"
echo "  ╔══════════════════════════════════════╗"
echo "  ║   H Y P R L A N D   D O T F I L E S  ║"
echo "  ║     super sinister · black & red     ║"
echo "  ║       https://pxdays.github.io       ║"
echo "  ╚══════════════════════════════════════╝"
echo -e "${N}"

# ── Check if running as root ──
if [ "$EUID" -eq 0 ]; then
  echo -e "${R}✗${N} Do not run this script as root or with sudo. It will ask for sudo when needed."
  exit 1
fi

# ── Detect distro ──
echo -e "${B}::${N} Detecting system..."

PKG_MANAGER=""
PKG_UPDATE=""
PKG_INSTALL=""
DISTRO=""

if command -v pacman &>/dev/null; then
  PKG_MANAGER="pacman"
  PKG_UPDATE="sudo pacman -Syu --noconfirm"
  PKG_INSTALL="sudo pacman -S --needed --noconfirm"
  DISTRO="arch"
  echo -e "  ${G}✓${N} Arch Linux detected"
elif command -v apt &>/dev/null; then
  echo -e "  ${Y}!${N} Debian/Ubuntu detected — not fully supported. Script will try its best."
  PKG_MANAGER="apt"
  PKG_UPDATE="sudo apt update"
  PKG_INSTALL="sudo apt install -y"
  DISTRO="debian"
elif command -v dnf &>/dev/null; then
  echo -e "  ${Y}!${N} Fedora detected — not fully supported. Script will try its best."
  PKG_MANAGER="dnf"
  PKG_UPDATE="sudo dnf check-update || true"
  PKG_INSTALL="sudo dnf install -y"
  DISTRO="fedora"
else
  echo -e "${R}✗${N} Could not detect your package manager."
  echo "  Supported: Arch Linux (pacman), Debian/Ubuntu (apt), Fedora (dnf)"
  exit 1
fi

# ── Check for yay/paru (AUR helper) on Arch ──
AUR_HELPER=""
if [ "$DISTRO" = "arch" ]; then
  if command -v paru &>/dev/null; then
    AUR_HELPER="paru"
    echo -e "    AUR helper: paru"
  elif command -v yay &>/dev/null; then
    AUR_HELPER="yay"
    echo -e "    AUR helper: yay"
  else
    echo -e "  ${Y}⚠${N} No AUR helper found (paru/yay). Some packages may be missing."
    echo "    Install paru: sudo pacman -S --needed base-devel git && git clone https://aur.archlinux.org/paru.git && cd paru && makepkg -si"
  fi
fi

# ── Package lists ──
ARCH_PKGS=(
  hyprland waybar wofi rofi-lbonn-wayland dunst alacritty thunar
  swaync pavucontrol pamixer brightnessctl playerctl mako
  ttf-jetbrains-mono-nerd ttf-font-awesome noto-fonts-emoji
  polkit-kde-agent qt5-wayland qt6-wayland xdg-desktop-portal-hyprland
  swappy grim slurp wl-clipboard cliphist
  network-manager-applet blueman
  pipewire pipewire-pulse wireplumber
  python python-pip python-requests
  starship neovim git curl wget unzip zip
)

ARCH_AUR=(
  hyprshot swww nwg-look nwg-displays
)

DEBIAN_PKGS=(
  hyprland waybar wofi dunst alacritty thunar
  pavucontrol playerctl mako
  fonts-jetbrains-mono fonts-font-awesome
  pipewire pipewire-pulse wireplumber
  python3 python3-pip
  neovim git curl wget unzip zip
)

echo ""
echo -e "${B}::${N} Installing packages..."

if [ "$PKG_MANAGER" = "pacman" ]; then
  echo -e "  ${Y}→${N} Updating system..."
  $PKG_UPDATE 2>/dev/null || true

  echo -e "  ${Y}→${N} Installing Hyprland and dependencies..."
  $PKG_INSTALL "${ARCH_PKGS[@]}" 2>/dev/null || true

  if [ -n "$AUR_HELPER" ]; then
    echo -e "  ${Y}→${N} Installing AUR packages..."
    $AUR_HELPER -S --needed --noconfirm "${ARCH_AUR[@]}" 2>/dev/null || true
  fi
elif [ "$PKG_MANAGER" = "apt" ]; then
  $PKG_UPDATE 2>/dev/null || true
  $PKG_INSTALL "${DEBIAN_PKGS[@]}" 2>/dev/null || true
elif [ "$PKG_MANAGER" = "dnf" ]; then
  $PKG_UPDATE 2>/dev/null || true
  $PKG_INSTALL "${DEBIAN_PKGS[@]}" 2>/dev/null || true
fi

# ── Backup existing config ──
BACKUP_DIR="$HOME/.config/hypr-backup-$(date +%Y%m%d-%H%M%S)"
if [ -d "$HOME/.config/hypr" ]; then
  echo ""
  echo -e "${Y}::${N} Backing up existing Hyprland config..."
  mv "$HOME/.config/hypr" "$BACKUP_DIR"
  echo -e "  ${G}✓${N} Backed up to: $BACKUP_DIR"
fi

# ── Get the script's directory ──
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Copy dotfiles ──
echo ""
echo -e "${B}::${N} Copying dotfiles..."

# Handle the hypr config (the install.sh is inside the extracted folder)
if [ -d "$SCRIPT_DIR/hypr" ]; then
  # Installer is inside the full hypr folder
  cp -r "$SCRIPT_DIR/.." "$HOME/.config/hypr" 2>/dev/null || cp -r "$SCRIPT_DIR" "$HOME/.config/hypr" 
elif [ -d "$(dirname "$SCRIPT_DIR")/hypr" ]; then
  # Installer is in a subfolder
  cp -r "$(dirname "$SCRIPT_DIR")" "$HOME/.config/hypr"
else
  # Assume all files are in the same directory as the installer
  mkdir -p "$HOME/.config/hypr"
  cp -r "$SCRIPT_DIR"/* "$HOME/.config/hypr/"
fi

echo -e "  ${G}✓${N} Dotfiles applied to ~/.config/hypr"

# ── Create necessary directories ──
mkdir -p "$HOME/.local/bin"
mkdir -p "$HOME/Pictures/wallpapers"

# ── Create a default wallpaper placeholder ──
WALLPAPER="$HOME/Pictures/wallpapers/arch-red.png"
if [ ! -f "$WALLPAPER" ]; then
  # Create a solid red image as default wallpaper using python/imagemagick
  if command -v convert &>/dev/null; then
    convert -size 1920x1080 xc:\#1a0000 "$WALLPAPER" 2>/dev/null || true
  elif command -v python3 &>/dev/null; then
    python3 -c "
import struct, zlib
def create_png(w,h,color):
    raw = b''
    for y in range(h):
        raw += b'\\x00' + bytes(color)*w
    def chunk(t,d): return struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    ihdr = struct.pack('>IIBBBBB',w,h,8,2,0,0,0)
    return b'\\x89PNG\\r\\n\\x1a\\n'+chunk(b'IHDR',ihdr)+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'')
with open('$WALLPAPER','wb') as f: f.write(create_png(1920,1080,(0x1a,0x00,0x00)))
" 2>/dev/null || true
  fi
fi

# ── Create volume-osd script if missing ──
if [ ! -f "$HOME/.local/bin/volume-osd" ]; then
  cat > "$HOME/.local/bin/volume-osd" << 'VOLEOF'
#!/usr/bin/env bash
case "${1:-}" in
  up) pamixer -i 5 ;;
  down) pamixer -d 5 ;;
  mute) pamixer -t ;;
esac
VOLEOF
  chmod +x "$HOME/.local/bin/volume-osd"
fi

# ── Create wob-start if missing ──
if [ ! -f "$HOME/.local/bin/wob-start.sh" ]; then
  cat > "$HOME/.local/bin/wob-start.sh" << 'WOBEOF'
#!/usr/bin/env bash
pkill wob 2>/dev/null || true
wob &
WOBEOF
  chmod +x "$HOME/.local/bin/wob-start.sh"
fi

# ── Fix permissions ──
echo ""
echo -e "${B}::${N} Fixing permissions..."
chmod -R +x "$HOME/.config/hypr/UserScripts" 2>/dev/null || true
chmod -R +x "$HOME/.config/hypr/scripts" 2>/dev/null || true

# ── Done ──
echo ""
echo -e "${G}════════════════════════════════════════${N}"
echo -e "${G}  ✅ INSTALLATION COMPLETE${N}"
echo -e "${G}════════════════════════════════════════${N}"
echo ""
echo -e "  ${C}→${N} Reboot or run: ${W}hyprland${N}"
echo -e "  ${C}→${N} If already in Hyprland: ${W}super shift M${N} to reload"
echo ""
echo -e "  ${Y}📁 Config location:${N} ~/.config/hypr/"
echo -e "  ${Y}🖼️  Wallpapers:${N} ~/Pictures/wallpapers/"
echo -e "  ${Y}🐞 Issues:${N} https://github.com/pxdays"
echo ""
echo -e "  ${R}🖤❤️  Super sinister black & red theme by pxdays${N}"
echo ""

# ── Copy power mode switcher ──
cp "$SCRIPT_DIR/home-scripts/waybar-powermode" "$HOME/.local/bin/" 2>/dev/null || true
chmod +x "$HOME/.local/bin/waybar-powermode" 2>/dev/null || true
